package com.example.smartcalculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.smartcalculator.ui.CalculatorScreen
import com.example.smartcalculator.ui.CalculatorViewModel
import com.example.smartcalculator.ui.theme.SmartCalculatorTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val viewModel: CalculatorViewModel = viewModel()
            val uiState by viewModel.uiState.collectAsState()
            val userSettings by viewModel.userSettings.collectAsState()
            val history by viewModel.historyList.collectAsState()

            SmartCalculatorTheme(themeMode = userSettings.themeMode) {
                CalculatorScreen(
                    uiState = uiState,
                    userSettings = userSettings,
                    history = history,
                    onAction = viewModel::onAction,
                    onClearHistory = viewModel::clearHistory,
                    onThemeChanged = viewModel::updateThemeMode,
                    onHapticChanged = viewModel::updateHaptic,
                    onSoundChanged = viewModel::updateSound,
                    onToggleDegreeMode = viewModel::toggleDegreeMode
                )
            }
        }
    }
}
