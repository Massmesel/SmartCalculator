package com.example.smartcalculator.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.smartcalculator.data.*
import com.example.smartcalculator.domain.EvalResult
import com.example.smartcalculator.domain.MathEvaluator
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class CalculatorUiState(
    val expression: String = "",
    val livePreview: String = "",
    val isError: Boolean = false,
    val isScientificExpanded: Boolean = true
)

sealed class CalculatorAction {
    data class Number(val digit: String) : CalculatorAction()
    data class Operator(val symbol: String) : CalculatorAction()
    data class Function(val func: String) : CalculatorAction()
    data object Decimal : CalculatorAction()
    data object Clear : CalculatorAction()
    data object Delete : CalculatorAction()
    data object Parentheses : CalculatorAction()
    data object ToggleSign : CalculatorAction()
    data object Square : CalculatorAction()
    data object Power : CalculatorAction()
    data object Reciprocal : CalculatorAction()
    data object Percentage : CalculatorAction()
    data object Evaluate : CalculatorAction()
    data object ToggleScientificPanel : CalculatorAction()
    data class LoadFromHistory(val expression: String, val result: String) : CalculatorAction()
}

class CalculatorViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = AppDatabase.getDatabase(application).calculationDao()
    private val prefsRepo = UserPreferencesRepository(application)

    private val _uiState = MutableStateFlow(CalculatorUiState())
    val uiState: StateFlow<CalculatorUiState> = _uiState.asStateFlow()

    val historyList: StateFlow<List<CalculationEntity>> = dao.getAllHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userSettings: StateFlow<UserSettings> = prefsRepo.userSettingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserSettings())

    fun onAction(action: CalculatorAction) {
        when (action) {
            is CalculatorAction.Number -> appendNumber(action.digit)
            is CalculatorAction.Operator -> appendOperator(action.symbol)
            is CalculatorAction.Function -> appendFunction(action.func)
            is CalculatorAction.Decimal -> appendDecimal()
            is CalculatorAction.Clear -> _uiState.value = _uiState.value.copy(
                expression = "",
                livePreview = "",
                isError = false
            )
            is CalculatorAction.Delete -> deleteLast()
            is CalculatorAction.Parentheses -> appendSmartParenthesis()
            is CalculatorAction.ToggleSign -> togglePlusMinus()
            is CalculatorAction.Square -> appendSquare()
            is CalculatorAction.Power -> appendOperator("^")
            is CalculatorAction.Reciprocal -> appendReciprocal()
            is CalculatorAction.Percentage -> appendPercentage()
            is CalculatorAction.Evaluate -> evaluateFinalResult()
            is CalculatorAction.ToggleScientificPanel -> {
                _uiState.update { it.copy(isScientificExpanded = !it.isScientificExpanded) }
            }
            is CalculatorAction.LoadFromHistory -> {
                _uiState.update {
                    it.copy(
                        expression = action.result,
                        livePreview = action.expression,
                        isError = false
                    )
                }
            }
        }
    }

    private fun appendNumber(digit: String) {
        val current = _uiState.value.expression
        val next = if (current == "0") digit else current + digit
        updateExpression(next)
    }

    private fun appendOperator(symbol: String) {
        val current = _uiState.value.expression
        if (current.isEmpty()) {
            if (symbol == "−" || symbol == "-") {
                updateExpression("-")
            }
            return
        }
        val lastChar = current.last()
        val operators = setOf('+', '−', '-', '×', '÷', '^')
        val next = if (lastChar in operators) {
            current.dropLast(1) + symbol
        } else {
            current + symbol
        }
        updateExpression(next)
    }

    private fun appendFunction(func: String) {
        val current = _uiState.value.expression
        val next = current + "$func("
        updateExpression(next)
    }

    private fun appendDecimal() {
        val current = _uiState.value.expression
        val lastNumberToken = current.split(Regex("[+−\\-×÷^()]")).lastOrNull() ?: ""
        if (!lastNumberToken.contains(".")) {
            val prefix = if (lastNumberToken.isEmpty()) "0." else "."
            updateExpression(current + prefix)
        }
    }

    private fun deleteLast() {
        val current = _uiState.value.expression
        if (current.isEmpty()) return

        val functions = listOf("sin(", "cos(", "tan(", "log(", "√(")
        val matchedFunc = functions.firstOrNull { current.endsWith(it) }

        val next = if (matchedFunc != null) {
            current.dropLast(matchedFunc.length)
        } else {
            current.dropLast(1)
        }
        updateExpression(next)
    }

    private fun appendSmartParenthesis() {
        val current = _uiState.value.expression
        val openCount = current.count { it == '(' }
        val closeCount = current.count { it == ')' }
        val lastChar = current.lastOrNull()

        val next = if (openCount > closeCount && (lastChar?.isDigit() == true || lastChar == ')' || lastChar == '%')) {
            "$current)"
        } else {
            "$current("
        }
        updateExpression(next)
    }

    private fun togglePlusMinus() {
        val current = _uiState.value.expression
        if (current.isEmpty()) {
            updateExpression("(-")
            return
        }
        if (current.endsWith("(-")) {
            updateExpression(current.dropLast(2))
            return
        }

        var i = current.length - 1
        while (i >= 0 && (current[i].isDigit() || current[i] == '.')) {
            i--
        }
        val numberPart = current.substring(i + 1)
        val beforePart = current.substring(0, i + 1)

        if (beforePart.endsWith("(-")) {
            updateExpression(beforePart.dropLast(2) + numberPart)
        } else {
            updateExpression("$beforePart(-$numberPart")
        }
    }

    private fun appendSquare() {
        val current = _uiState.value.expression
        if (current.isNotEmpty() && (current.last().isDigit() || current.last() == ')')) {
            updateExpression("$current^2")
        }
    }

    private fun appendReciprocal() {
        val current = _uiState.value.expression
        if (current.isEmpty()) {
            updateExpression("1÷")
        } else {
            updateExpression("1÷($current)")
        }
    }

    private fun appendPercentage() {
        val current = _uiState.value.expression
        if (current.isNotEmpty() && (current.last().isDigit() || current.last() == ')')) {
            updateExpression("$current%")
        }
    }

    private fun updateExpression(newExpr: String) {
        if (newExpr.isBlank()) {
            _uiState.value = _uiState.value.copy(expression = "", livePreview = "", isError = false)
            return
        }

        val isDeg = userSettings.value.isDegreeMode
        val eval = MathEvaluator.evaluate(newExpr, isDeg)
        val preview = when (eval) {
            is EvalResult.Success -> if (eval.value != newExpr) eval.value else ""
            is EvalResult.Error -> ""
        }

        _uiState.value = _uiState.value.copy(
            expression = newExpr,
            livePreview = preview,
            isError = false
        )
    }

    private fun evaluateFinalResult() {
        val current = _uiState.value.expression
        if (current.isBlank()) return

        val isDeg = userSettings.value.isDegreeMode
        when (val eval = MathEvaluator.evaluate(current, isDeg)) {
            is EvalResult.Success -> {
                if (eval.value.isNotBlank()) {
                    viewModelScope.launch {
                        dao.insertCalculation(
                            CalculationEntity(
                                expression = current,
                                result = eval.value
                            )
                        )
                    }
                    _uiState.value = _uiState.value.copy(
                        expression = eval.value,
                        livePreview = "",
                        isError = false
                    )
                }
            }
            is EvalResult.Error -> {
                _uiState.value = _uiState.value.copy(
                    livePreview = eval.message,
                    isError = true
                )
            }
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            dao.clearAllHistory()
        }
    }

    fun updateThemeMode(mode: ThemeMode) {
        viewModelScope.launch { prefsRepo.setThemeMode(mode) }
    }

    fun updateHaptic(enabled: Boolean) {
        viewModelScope.launch { prefsRepo.setHapticEnabled(enabled) }
    }

    fun updateSound(enabled: Boolean) {
        viewModelScope.launch { prefsRepo.setSoundEnabled(enabled) }
    }

    fun toggleDegreeMode() {
        viewModelScope.launch {
            prefsRepo.setDegreeMode(!userSettings.value.isDegreeMode)
            updateExpression(_uiState.value.expression)
        }
    }
}
