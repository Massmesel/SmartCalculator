package com.example.smartcalculator.domain

import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.*

sealed class EvalResult {
    data class Success(val value: String) : EvalResult()
    data class Error(val message: String) : EvalResult()
}

object MathEvaluator {

    fun evaluate(rawExpression: String, isDegreeMode: Boolean = true): EvalResult {
        if (rawExpression.isBlank()) return EvalResult.Success("")

        try {
            var expr = rawExpression
                .replace("×", "*")
                .replace("÷", "/")
                .replace("−", "-")
                .replace("√(", "sqrt(")
                .replace("√", "sqrt")
                .replace("π", Math.PI.toString())
                .replace("e", Math.E.toString())
                .replace(" ", "")

            val openCount = expr.count { it == '(' }
            val closeCount = expr.count { it == ')' }
            if (openCount > closeCount) {
                expr += ")".repeat(openCount - closeCount)
            }

            expr = expr.replace(Regex("(\\d+(?:\\.\\d+)?)%")) { matchResult ->
                "(${matchResult.groupValues[1]}/100)"
            }

            expr = expr.replace(Regex("(\\d)(\\()"), "$1*$2")
            expr = expr.replace(Regex("(\\))(\\d)"), "$1*$2")
            expr = expr.replace(Regex("(\\))(\\()"), "$1*$2")
            expr = expr.replace(Regex("(\\d)(sin|cos|tan|log|ln|sqrt)"), "$1*$2")
            expr = expr.replace(Regex("(\\))(sin|cos|tan|log|ln|sqrt)"), "$1*$2")

            val result = RecursiveDescentParser(expr, isDegreeMode).parse()

            if (result.isNaN()) return EvalResult.Error("Undefined")
            if (result.isInfinite()) return EvalResult.Error("Cannot divide by 0")

            return EvalResult.Success(formatResult(result))
        } catch (e: ArithmeticException) {
            return EvalResult.Error(e.message ?: "Math Error")
        } catch (e: IllegalArgumentException) {
            return EvalResult.Error(e.message ?: "Syntax Error")
        } catch (e: Exception) {
            return EvalResult.Error("Invalid Expression")
        }
    }

    private fun formatResult(value: Double): String {
        val bd = BigDecimal.valueOf(value).setScale(10, RoundingMode.HALF_UP).stripTrailingZeros()
        val plain = bd.toPlainString()
        return if (plain.replace("-", "").replace(".", "").length > 14) {
            String.format("%.6E", value).replace("E+", "E")
        } else {
            plain
        }
    }

    private class RecursiveDescentParser(
        private val input: String,
        private val isDegreeMode: Boolean
    ) {
        private var pos = -1
        private var ch = 0

        private fun nextChar() {
            ch = if (++pos < input.length) input[pos].code else -1
        }

        private fun eat(charToEat: Int): Boolean {
            while (ch == ' '.code) nextChar()
            if (ch == charToEat) {
                nextChar()
                return true
            }
            return false
        }

        fun parse(): Double {
            nextChar()
            val x = parseExpression()
            if (pos < input.length) throw IllegalArgumentException("Unexpected character: '${ch.toChar()}'")
            return x
        }

        private fun parseExpression(): Double {
            var x = parseTerm()
            while (true) {
                when {
                    eat('+'.code) -> x += parseTerm()
                    eat('-'.code) -> x -= parseTerm()
                    else -> return x
                }
            }
        }

        private fun parseTerm(): Double {
            var x = parseFactor()
            while (true) {
                when {
                    eat('*'.code) -> x *= parseFactor()
                    eat('/'.code) -> {
                        val denominator = parseFactor()
                        if (abs(denominator) < 1e-15) {
                            throw ArithmeticException("Cannot divide by 0")
                        }
                        x /= denominator
                    }
                    else -> return x
                }
            }
        }

        private fun parseFactor(): Double {
            if (eat('+'.code)) return parseFactor()
            if (eat('-'.code)) return -parseFactor()

            var x: Double
            val startPos = this.pos

            if (eat('('.code)) {
                x = parseExpression()
                if (!eat(')'.code)) throw IllegalArgumentException("Missing ')'")
            } else if ((ch in '0'.code..'9'.code) || ch == '.'.code) {
                while ((ch in '0'.code..'9'.code) || ch == '.'.code || ch == 'E'.code) {
                    if (ch == 'E'.code) {
                        nextChar()
                        if (ch == '+'.code || ch == '-'.code) nextChar()
                    } else {
                        nextChar()
                    }
                }
                val numStr = input.substring(startPos, this.pos)
                x = numStr.toDoubleOrNull() ?: throw IllegalArgumentException("Invalid number")
            } else if (ch in 'a'.code..'z'.code) {
                while (ch in 'a'.code..'z'.code) nextChar()
                val func = input.substring(startPos, this.pos)
                x = parseFactor()
                x = when (func) {
                    "sqrt" -> {
                        if (x < 0) throw ArithmeticException("Invalid Root")
                        sqrt(x)
                    }
                    "sin" -> {
                        val rad = if (isDegreeMode) Math.toRadians(x) else x
                        val res = sin(rad)
                        if (abs(res) < 1e-15) 0.0 else res
                    }
                    "cos" -> {
                        val rad = if (isDegreeMode) Math.toRadians(x) else x
                        val res = cos(rad)
                        if (abs(res) < 1e-15) 0.0 else res
                    }
                    "tan" -> {
                        if (isDegreeMode && abs(x % 180.0) == 90.0) {
                            throw ArithmeticException("Undefined")
                        }
                        val rad = if (isDegreeMode) Math.toRadians(x) else x
                        val res = tan(rad)
                        if (abs(res) < 1e-15) 0.0 else res
                    }
                    "log" -> {
                        if (x <= 0) throw ArithmeticException("Invalid Log")
                        log10(x)
                    }
                    "ln" -> {
                        if (x <= 0) throw ArithmeticException("Invalid Ln")
                        ln(x)
                    }
                    else -> throw IllegalArgumentException("Unknown function: $func")
                }
            } else {
                throw IllegalArgumentException("Incomplete Expression")
            }

            if (eat('^'.code)) {
                val exponent = parseFactor()
                x = x.pow(exponent)
            }

            return x
        }
    }
}
