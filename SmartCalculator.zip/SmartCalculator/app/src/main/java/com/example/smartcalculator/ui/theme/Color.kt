package com.example.smartcalculator.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Palette
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE2E8F0)
val LightPrimary = Color(0xFF0284C7)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightSecondary = Color(0xFFF59E0B)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
val LightError = Color(0xFFDC2626)

// Dark Theme Palette
val DarkBackground = Color(0xFF0B1120)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)
val DarkPrimary = Color(0xFF38BDF8)
val DarkOnPrimary = Color(0xFF0F172A)
val DarkSecondary = Color(0xFFFBBF24)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkError = Color(0xFFF87171)
