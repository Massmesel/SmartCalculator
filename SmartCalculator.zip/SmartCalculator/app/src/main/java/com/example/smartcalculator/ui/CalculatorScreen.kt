package com.example.smartcalculator.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.media.AudioManager
import android.view.HapticFeedbackConstants
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.smartcalculator.data.CalculationEntity
import com.example.smartcalculator.data.ThemeMode
import com.example.smartcalculator.data.UserSettings

@Composable
fun CalculatorScreen(
    uiState: CalculatorUiState,
    userSettings: UserSettings,
    history: List<CalculationEntity>,
    onAction: (CalculatorAction) -> Unit,
    onClearHistory: () -> Unit,
    onThemeChanged: (ThemeMode) -> Unit,
    onHapticChanged: (Boolean) -> Unit,
    onSoundChanged: (Boolean) -> Unit,
    onToggleDegreeMode: () -> Unit
) {
    val context = LocalContext.current
    val view = LocalView.current

    var showHistorySheet by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }

    val triggerFeedback = {
        if (userSettings.hapticEnabled) {
            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        }
        if (userSettings.soundEnabled) {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            audioManager?.playSoundEffect(AudioManager.FX_KEY_CLICK)
        }
    }

    val copyToClipboard = { textToCopy: String ->
        if (textToCopy.isNotBlank()) {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("Calculation Result", textToCopy)
            clipboard.setPrimaryClip(clip)
            Toast.makeText(context, "Copied: $textToCopy", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilledTonalButton(
                    onClick = {
                        triggerFeedback()
                        onToggleDegreeMode()
                    },
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = if (userSettings.isDegreeMode) "DEG" else "RAD",
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = {
                        triggerFeedback()
                        onAction(CalculatorAction.ToggleScientificPanel)
                    }) {
                        Icon(
                            imageVector = Icons.Outlined.Science,
                            contentDescription = "Toggle Scientific Functions",
                            tint = if (uiState.isScientificExpanded) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                    }

                    IconButton(onClick = {
                        triggerFeedback()
                        val target = uiState.livePreview.ifBlank { uiState.expression }
                        copyToClipboard(target)
                    }) {
                        Icon(
                            imageVector = Icons.Outlined.ContentCopy,
                            contentDescription = "Copy Result",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    IconButton(onClick = {
                        triggerFeedback()
                        showHistorySheet = true
                    }) {
                        Icon(
                            imageVector = Icons.Outlined.History,
                            contentDescription = "Calculation History",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    IconButton(onClick = {
                        triggerFeedback()
                        showSettingsDialog = true
                    }) {
                        Icon(
                            imageVector = Icons.Outlined.Settings,
                            contentDescription = "Settings",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            DisplayPanel(
                expression = uiState.expression,
                livePreview = uiState.livePreview,
                isError = uiState.isError,
                onLongPressCopy = {
                    val target = uiState.livePreview.ifBlank { uiState.expression }
                    copyToClipboard(target)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.32f)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.68f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AnimatedVisibility(
                    visible = uiState.isScientificExpanded,
                    enter = expandVertically(),
                    exit = shrinkVertically()
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ScientificButton("sin", Modifier.weight(1f)) {
                                triggerFeedback()
                                onAction(CalculatorAction.Function("sin"))
                            }
                            ScientificButton("cos", Modifier.weight(1f)) {
                                triggerFeedback()
                                onAction(CalculatorAction.Function("cos"))
                            }
                            ScientificButton("tan", Modifier.weight(1f)) {
                                triggerFeedback()
                                onAction(CalculatorAction.Function("tan"))
                            }
                            ScientificButton("log", Modifier.weight(1f)) {
                                triggerFeedback()
                                onAction(CalculatorAction.Function("log"))
                            }
                            ScientificButton("( )", Modifier.weight(1f)) {
                                triggerFeedback()
                                onAction(CalculatorAction.Parentheses)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ScientificButton("√", Modifier.weight(1f)) {
                                triggerFeedback()
                                onAction(CalculatorAction.Function("√"))
                            }
                            ScientificButton("x²", Modifier.weight(1f)) {
                                triggerFeedback()
                                onAction(CalculatorAction.Square)
                            }
                            ScientificButton("xʸ", Modifier.weight(1f)) {
                                triggerFeedback()
                                onAction(CalculatorAction.Power)
                            }
                            ScientificButton("1/x", Modifier.weight(1f)) {
                                triggerFeedback()
                                onAction(CalculatorAction.Reciprocal)
                            }
                            ScientificButton("+/-", Modifier.weight(1f)) {
                                triggerFeedback()
                                onAction(CalculatorAction.ToggleSign)
                            }
                        }
                    }
                }

                val mainRows = listOf(
                    listOf(
                        CalcBtnSpec("AC", CalcBtnType.ACTION) { onAction(CalculatorAction.Clear) },
                        CalcBtnSpec("DEL", CalcBtnType.ACTION) { onAction(CalculatorAction.Delete) },
                        CalcBtnSpec("%", CalcBtnType.OPERATOR) { onAction(CalculatorAction.Percentage) },
                        CalcBtnSpec("÷", CalcBtnType.OPERATOR) { onAction(CalculatorAction.Operator("÷")) }
                    ),
                    listOf(
                        CalcBtnSpec("7", CalcBtnType.NUMBER) { onAction(CalculatorAction.Number("7")) },
                        CalcBtnSpec("8", CalcBtnType.NUMBER) { onAction(CalculatorAction.Number("8")) },
                        CalcBtnSpec("9", CalcBtnType.NUMBER) { onAction(CalculatorAction.Number("9")) },
                        CalcBtnSpec("×", CalcBtnType.OPERATOR) { onAction(CalculatorAction.Operator("×")) }
                    ),
                    listOf(
                        CalcBtnSpec("4", CalcBtnType.NUMBER) { onAction(CalculatorAction.Number("4")) },
                        CalcBtnSpec("5", CalcBtnType.NUMBER) { onAction(CalculatorAction.Number("5")) },
                        CalcBtnSpec("6", CalcBtnType.NUMBER) { onAction(CalculatorAction.Number("6")) },
                        CalcBtnSpec("−", CalcBtnType.OPERATOR) { onAction(CalculatorAction.Operator("−")) }
                    ),
                    listOf(
                        CalcBtnSpec("1", CalcBtnType.NUMBER) { onAction(CalculatorAction.Number("1")) },
                        CalcBtnSpec("2", CalcBtnType.NUMBER) { onAction(CalculatorAction.Number("2")) },
                        CalcBtnSpec("3", CalcBtnType.NUMBER) { onAction(CalculatorAction.Number("3")) },
                        CalcBtnSpec("+", CalcBtnType.OPERATOR) { onAction(CalculatorAction.Operator("+")) }
                    ),
                    listOf(
                        CalcBtnSpec("0", CalcBtnType.NUMBER) { onAction(CalculatorAction.Number("0")) },
                        CalcBtnSpec(".", CalcBtnType.NUMBER) { onAction(CalculatorAction.Decimal) },
                        CalcBtnSpec("=", CalcBtnType.EQUAL, weight = 2f) { onAction(CalculatorAction.Evaluate) }
                    )
                )

                mainRows.forEach { rowSpecs ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        rowSpecs.forEach { spec ->
                            CalculatorButton(
                                label = spec.label,
                                type = spec.type,
                                modifier = Modifier
                                    .weight(spec.weight)
                                    .fillMaxHeight(),
                                onClick = {
                                    triggerFeedback()
                                    spec.onClick()
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showHistorySheet) {
        HistoryBottomSheet(
            history = history,
            onDismiss = { showHistorySheet = false },
            onClearHistory = onClearHistory,
            onSelectHistoryItem = { item ->
                onAction(CalculatorAction.LoadFromHistory(item.expression, item.result))
            },
            onCopyResult = copyToClipboard
        )
    }

    if (showSettingsDialog) {
        SettingsDialog(
            settings = userSettings,
            onDismiss = { showSettingsDialog = false },
            onThemeChanged = onThemeChanged,
            onHapticChanged = onHapticChanged,
            onSoundChanged = onSoundChanged
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DisplayPanel(
    expression: String,
    livePreview: String,
    isError: Boolean,
    onLongPressCopy: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    LaunchedEffect(expression) {
        scrollState.animateScrollTo(scrollState.maxValue)
    }

    val dynamicFontSize: TextUnit = when {
        expression.length > 18 -> 30.sp
        expression.length > 12 -> 38.sp
        else -> 48.sp
    }

    Surface(
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        modifier = modifier.combinedClickable(
            onClick = {},
            onLongClick = onLongPressCopy
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.Bottom,
            horizontalAlignment = Alignment.End
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(scrollState),
                contentAlignment = Alignment.CenterEnd
            ) {
                Text(
                    text = expression.ifEmpty { "0" },
                    fontSize = dynamicFontSize,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.End,
                    maxLines = 1,
                    softWrap = false
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (livePreview.isNotEmpty()) {
                    if (isError) livePreview else "= $livePreview"
                } else "",
                style = MaterialTheme.typography.headlineMedium,
                color = if (isError) {
                    MaterialTheme.colorScheme.error
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.End
            )
        }
    }
}

private enum class CalcBtnType {
    NUMBER, OPERATOR, ACTION, EQUAL
}

private data class CalcBtnSpec(
    val label: String,
    val type: CalcBtnType,
    val weight: Float = 1f,
    val onClick: () -> Unit
)

@Composable
private fun CalculatorButton(
    label: String,
    type: CalcBtnType,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.92f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 600f),
        label = "btn_scale"
    )

    val containerColor: Color
    val contentColor: Color

    when (type) {
        CalcBtnType.NUMBER -> {
            containerColor = MaterialTheme.colorScheme.surface
            contentColor = MaterialTheme.colorScheme.onSurface
        }
        CalcBtnType.OPERATOR -> {
            containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
            contentColor = MaterialTheme.colorScheme.primary
        }
        CalcBtnType.ACTION -> {
            containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.15f)
            contentColor = MaterialTheme.colorScheme.error
        }
        CalcBtnType.EQUAL -> {
            containerColor = MaterialTheme.colorScheme.primary
            contentColor = MaterialTheme.colorScheme.onPrimary
        }
    }

    Surface(
        onClick = onClick,
        interactionSource = interactionSource,
        shape = RoundedCornerShape(24.dp),
        color = containerColor,
        contentColor = contentColor,
        shadowElevation = if (type == CalcBtnType.NUMBER) 1.dp else 0.dp,
        modifier = modifier.scale(scale)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                fontSize = if (label.length > 1) 20.sp else 26.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun ScientificButton(
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.90f else 1f,
        label = "sci_scale"
    )

    Surface(
        onClick = onClick,
        interactionSource = interactionSource,
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
        contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = modifier
            .height(42.dp)
            .scale(scale)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
